package com.jaggrat.sample

import android.app.Application

class NewsApp : Application() {

}